#include <stdio.h>
int main()
{
   int i=1,n;
   printf("enter the number n");
   scanf("%d",&n);
   while(i<=20)
   {
       printf("%d * %d=%d\n",i,n,n*i);
       ++i;
   }
}